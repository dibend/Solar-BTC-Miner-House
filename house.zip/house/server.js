const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const { exec } = require('child_process');
const app = express();
const port = 3000;


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Shared Threshold Update
app.post('/update-top-threshold', (req, res) => {
    fs.writeFileSync('top-threshold.csv', req.body.threshold);
    res.send('Shared threshold updated successfully.');
});

// Shared Threshold Update
app.post('/update-bottom-threshold', (req, res) => {
    fs.writeFileSync('bottom-threshold.csv', req.body.threshold);
    res.send('Shared threshold updated successfully.');
});
// Device .24 Configuration
app.post('/update-tp-24', (req, res) => {
    fs.writeFileSync('tp.csv', req.body.tp);
    res.send('Top Profile for .24 updated successfully.');
});
app.post('/update-bp-24', (req, res) => {
    fs.writeFileSync('bp24.csv', req.body.bp);
    res.send('Bottom Profile for .24 updated successfully.');
});

// Device .25 Configuration
app.post('/update-tp-25', (req, res) => {
    fs.writeFileSync('tp25.csv', req.body.tp);
    res.send('Top Profile for .25 updated successfully.');
});
app.post('/update-bp-25', (req, res) => {
    fs.writeFileSync('bp25.csv', req.body.bp);
    res.send('Bottom Profile for .25 updated successfully.');
});

// Device .26 Configuration
app.post('/update-tp-26', (req, res) => {
    fs.writeFileSync('tp26.csv', req.body.tp);
    res.send('Top Profile for .26 updated successfully.');
});
app.post('/update-bp-26', (req, res) => {
    fs.writeFileSync('bp26.csv', req.body.bp);
    res.send('Bottom Profile for .26 updated successfully.');
});

// Device .27 Configuration
app.post('/update-tp-27', (req, res) => {
    fs.writeFileSync('tp27.csv', req.body.tp);
    res.send('Top Profile for .27 updated successfully.');
});
app.post('/update-bp-27', (req, res) => {
    fs.writeFileSync('bp27.csv', req.body.bp);
    res.send('Bottom Profile for .27 updated successfully.');
});

// Device .21 Configuration
app.post('/update-tp-21', (req, res) => {
    fs.writeFileSync('tp21.csv', req.body.tp);
    res.send('Top Profile for .21 updated successfully.');
});
app.post('/update-bp-21', (req, res) => {
    fs.writeFileSync('bp21.csv', req.body.bp);
    res.send('Bottom Profile for .21 updated successfully.');
});
app.get('/voltage', (req, res) => {
    const voltageFilePath = '/home/100acresranch/house/voltage.csv';

    fs.readFile(voltageFilePath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Failed to read the file');
        }

        // Split the file content by new line and get the last non-empty line
        const lines = data.trim().split('\n');
        const lastLine = lines[lines.length - 1];

        // Set the header to indicate the content type as plaintext
        res.setHeader('Content-Type', 'text/plain');
        res.send(lastLine);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

